from django.db import models


# Create your models here.
class User(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(max_length=100, primary_key=True)
    password = models.CharField(max_length=20)
    dob = models.DateField()
    gender = models.CharField(max_length=1)
    active = models.BooleanField(default=False)


class Url(models.Model):
    long_url = models.URLField(max_length=1000)
    short_url = models.CharField(max_length=10)
    email = models.ForeignKey(User, on_delete=models.CASCADE)
