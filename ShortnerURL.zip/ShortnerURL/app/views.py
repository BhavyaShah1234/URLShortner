import string
from django.shortcuts import render, redirect
from django.utils.crypto import get_random_string
from . import models


# Create your views here.
def index(request):
    return render(request, 'index.html')


def signup(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        dob = request.POST['dob']
        gender = request.POST['gender']
        query = models.User.objects.filter(email=email)
        if len(query) == 0:
            query = models.User.objects.create(first_name=first_name,
                                               last_name=last_name,
                                               email=email,
                                               password=password,
                                               dob=dob,
                                               gender=gender)
            query.save()
            return redirect(f'/login/?email={email}')
        else:
            return redirect('/error/?error=user-exists')
    return render(request, 'signup.html')


def error(request):
    error_message = request.GET.get('error')
    if error_message == 'user-exists':
        return render(request, 'error.html', {'error_message': 'USER ALREADY EXISTS'})
    elif error_message == 'no-user':
        return render(request, 'error.html', {'error_message': 'NO SUCH USER'})
    else:
        return redirect('/')


def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        query = models.User.objects.filter(email=email, password=password)
        if len(query) > 0:
            query = models.User.objects.get(email=email)
            query.active = True
            query.save()
            return redirect(f'/home/?email={email}')
        else:
            return redirect(f'/error/?error=no-user')
    return render(request, 'login.html')


def home(request):
    email = request.GET.get('email')
    if request.method == 'GET':
        query = models.User.objects.get(email=email)
        if query.active:
            first_name = query.first_name
            last_name = query.last_name
            urls = models.Url.objects.filter(email=email)
            return render(request, 'home.html', context={'first_name': first_name,
                                                         'last_name': last_name,
                                                         'urls': urls,
                                                         'email': email})
        else:
            return redirect(f'/login/?email={email}')
    else:
        query = models.User.objects.get(email=email)
        query.active = False
        query.save()
        return redirect(f'/?email={email}')


def new(request):
    email = request.GET.get('email')
    query = models.User.objects.get(email=email)
    if request.method == 'POST':
        if query.active:
            long_url = request.POST['long_url']
            short_url = get_random_string(10, string.ascii_lowercase + string.digits + string.ascii_uppercase)
            query = models.User.objects.filter(email=email)
            if len(query) > 0:
                query = models.Url.objects.create(long_url=long_url, short_url=short_url, email_id=email)
                query.save()
                return redirect(f'/home/?email={email}')
        else:
            return redirect(f'/login/?email={email}')
    else:
        return render(request, 'new.html', context={'email': email})


def link(request):
    email = request.GET.get('email')
    url = request.GET.get('url')
    if request.method == 'GET':
        query = models.User.objects.get(email=email)
        if query.active:
            query = models.Url.objects.filter(email=email, short_url=url)
            if len(query) > 0:
                query = models.Url.objects.get(short_url=url)
                return redirect(query.long_url)
            else:
                return redirect(f'/home/?email={email}')
        else:
            return redirect(f'/login/?email={email}')
