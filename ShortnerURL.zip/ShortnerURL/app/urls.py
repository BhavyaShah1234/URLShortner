from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('error/', views.error, name='error'),
    path('home/', views.home, name='home'),
    path('new/', views.new, name='new'),
    path('link/', views.link, name='link'),
]
